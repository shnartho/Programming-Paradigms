package Exercises.List_8.Task_4;

public enum FuelType {
    GASOLINE,
    DIESEL,
    ELECTRIC,
}
