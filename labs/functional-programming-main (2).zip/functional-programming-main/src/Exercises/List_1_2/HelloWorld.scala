package Exercises.List_1_2

object HelloWorld {
  def main(args: Array[String]): Unit = {
    println("Hello, world!")
    println(args(0))
  }
}